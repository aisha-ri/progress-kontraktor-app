export default function RekapPage() {
  return <div>Rekap Page Placeholder</div>;
}
