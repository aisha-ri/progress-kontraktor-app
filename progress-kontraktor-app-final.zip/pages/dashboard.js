export default function Dashboard() {
  return <div>Dashboard Page Placeholder</div>;
}
