export default function InputPage() {
  return <div>Input Page Placeholder</div>;
}
