// login.js (placeholder)
export default function Login() {
  return <div>Login Page Placeholder</div>;
}
